const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const app = express();
const port = 3000;

// Ścieżka do pliku bazy danych
const db = new sqlite3.Database('magazyn.db');

// Middleware
app.use(cors());
app.use(express.json());

// Tworzenie tabel, jeśli nie istnieją
db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS czesci (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nazwa TEXT,
      koszt REAL,
      ilosc INTEGER,
      marka TEXT,
      stan TEXT
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS historia (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      opis TEXT
    )
  `);
});

// Endpointy API

// Pobranie wszystkich części
app.get('/czesci', (req, res) => {
  db.all('SELECT * FROM czesci', (err, rows) => {
    if (err) return res.status(500).send(err.message);
    res.json(rows);
  });
});

// Dodanie nowej części
app.post('/czesci', (req, res) => {
  const { nazwa, koszt, ilosc, marka, stan } = req.body;
  db.run(
    'INSERT INTO czesci (nazwa, koszt, ilosc, marka, stan) VALUES (?, ?, ?, ?, ?)',
    [nazwa, koszt, ilosc, marka, stan],
    function(err) {
      if (err) return res.status(500).send(err.message);
      res.json({ id: this.lastID });
    }
  );
});

// Edytowanie części
app.put('/czesci/:id', (req, res) => {
  const { nazwa, koszt, ilosc, marka, stan } = req.body;
  db.run(
    'UPDATE czesci SET nazwa = ?, koszt = ?, ilosc = ?, marka = ?, stan = ? WHERE id = ?',
    [nazwa, koszt, ilosc, marka, stan, req.params.id],
    function(err) {
      if (err) return res.status(500).send(err.message);
      res.json({ changes: this.changes });
    }
  );
});

// Usuwanie części
app.delete('/czesci/:id', (req, res) => {
  db.run('DELETE FROM czesci WHERE id = ?', req.params.id, function(err) {
    if (err) return res.status(500).send(err.message);
    res.json({ changes: this.changes });
  });
});

// Pobranie historii
app.get('/historia', (req, res) => {
  db.all('SELECT * FROM historia', (err, rows) => {
    if (err) return res.status(500).send(err.message);
    res.json(rows);
  });
});

// Dodanie wpisu do historii
app.post('/historia', (req, res) => {
  const { opis } = req.body;
  db.run(
    'INSERT INTO historia (opis) VALUES (?)',
    [opis],
    function(err) {
      if (err) return res.status(500).send(err.message);
      res.json({ id: this.lastID });
    }
  );
});

// Start serwera
app.listen(port, () => {
  console.log(`Serwer działa na http://localhost:${port}`);
});
