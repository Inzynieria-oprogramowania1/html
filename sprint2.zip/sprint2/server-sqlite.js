const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const path = require('path');
const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Połączenie z bazą danych SQLite
const db = new sqlite3.Database('./magazyn.db', (err) => {
  if (err) {
    return console.error('Błąd połączenia z SQLite:', err.message);
  }
  console.log('Połączono z SQLite (magazyn.db)');
});

// Tworzenie tabeli jeśli nie istnieje
db.run(`
  CREATE TABLE IF NOT EXISTS czesci (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nazwa TEXT,
    koszt REAL,
    ilosc INTEGER,
    marka TEXT,
    stan TEXT
  )
`);

// Pobieranie części
app.get('/czesci', (req, res) => {
  db.all('SELECT * FROM czesci', [], (err, rows) => {
    if (err) {
      return res.status(500).send(err.message);
    }
    res.json(rows);
  });
});

// Dodawanie części
app.post('/czesci', (req, res) => {
  const { nazwa, koszt, ilosc, marka, stan } = req.body;
  const stmt = `INSERT INTO czesci (nazwa, koszt, ilosc, marka, stan) VALUES (?, ?, ?, ?, ?)`;
  db.run(stmt, [nazwa, koszt, ilosc, marka, stan], function (err) {
    if (err) {
      return res.status(500).send(err.message);
    }
    res.json({ message: 'Dodano część', id: this.lastID });
  });
});

// Uruchomienie serwera
app.listen(3000, () => {
  console.log('Serwer SQLite działa na http://localhost:3000');
});
