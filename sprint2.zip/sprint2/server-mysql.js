const express = require('express');
const mysql = require('mysql');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '', // <-- wpisz swoje hasło jeśli ustawiłeś w MySQL Workbench
  database: 'magazyn'
});

db.connect(err => {
  if (err) {
    console.error('Błąd połączenia z bazą danych:', err);
  } else {
    console.log('Połączono z MySQL (magazyn)');
  }
});

// Przykładowe zapytanie: pobierz wszystkie części
app.get('/czesci', (req, res) => {
  db.query('SELECT * FROM czesci', (err, results) => {
    if (err) {
      console.error('Błąd zapytania:', err);
      res.status(500).send('Błąd serwera');
    } else {
      res.json(results);
    }
  });
});

// Dodawanie części
app.post('/czesci', (req, res) => {
  const { nazwa, koszt, ilosc, marka, stan } = req.body;
  db.query(
    'INSERT INTO czesci (nazwa, koszt, ilosc, marka, stan) VALUES (?, ?, ?, ?, ?)',
    [nazwa, koszt, ilosc, marka, stan],
    (err, result) => {
      if (err) {
        console.error('Błąd dodawania:', err);
        res.status(500).send('Błąd serwera');
      } else {
        res.send('Dodano część');
      }
    }
  );
});

// Uruchomienie serwera
app.listen(3000, () => {
  console.log('Serwer działa na http://localhost:3000');
});
