function login() {
    const login = document.getElementById('login').value;
    const password = document.getElementById('password').value;
  
    if (login === 'admin' && password === 'admin') {
      document.getElementById('login-panel').style.display = 'none';
      document.getElementById('dashboard').style.display = 'block';
      alert('Zalogowano!');
    } else {
      alert('Niepoprawny login lub hasło.');
    }
  }
  
  function logout() {
    document.getElementById('dashboard').style.display = 'none';
    document.getElementById('login-panel').style.display = 'block';
  }
  