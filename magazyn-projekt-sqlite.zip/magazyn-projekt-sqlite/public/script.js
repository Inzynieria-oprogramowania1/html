// script.js

let czesci = [];
let historia = [];
let aktualnosci = [];
let chart;

function openTab(tabName) {
  const tabs = document.getElementsByClassName('tabcontent');
  for (let tab of tabs) {
    tab.style.display = 'none';
  }
  document.getElementById(tabName).style.display = 'block';
  if (tabName === 'statystyki') {
    renderStatystyki();
  }
}

window.onload = function() {
  const userName = localStorage.getItem('userName');
  const userEmail = localStorage.getItem('userEmail');
  const userPhone = localStorage.getItem('userPhone');
  if (!userName) {
    document.getElementById('loginScreen').style.display = 'block';
    document.getElementById('mainContent').style.display = 'none';
  } else {
    document.getElementById('loginScreen').style.display = 'none';
    document.getElementById('mainContent').style.display = 'block';
    document.getElementById('userName').textContent = userName;
    document.getElementById('userEmail').textContent = userEmail || '';
    document.getElementById('userPhone').textContent = userPhone || '';
    loadData();
  }
};

function login() {
  const name = document.getElementById('loginInput').value.trim();
  if (name) {
    localStorage.setItem('userName', name);
    document.getElementById('userName').textContent = name;
    document.getElementById('loginScreen').style.display = 'none';
    document.getElementById('mainContent').style.display = 'block';
    loadData();
  } else {
    alert('Wpisz swoje imię!');
  }
}

function loadData() {
  const savedCzesci = localStorage.getItem('czesci');
  if (savedCzesci) czesci = JSON.parse(savedCzesci);

  const savedHistoria = localStorage.getItem('historia');
  if (savedHistoria) historia = JSON.parse(savedHistoria);

  const savedAktualnosci = localStorage.getItem('aktualnosci');
  if (savedAktualnosci) aktualnosci = JSON.parse(savedAktualnosci);

  openTab('czesci');
  renderCzesci();
  renderHistoria();
  renderAktualnosci();
}

function saveData() {
  localStorage.setItem('czesci', JSON.stringify(czesci));
  localStorage.setItem('historia', JSON.stringify(historia));
  localStorage.setItem('aktualnosci', JSON.stringify(aktualnosci));
}

document.addEventListener('submit', function(event) {
  if (event.target && event.target.id === 'dodajCzescForm') {
    event.preventDefault();
    const nazwa = document.getElementById('nazwa').value.trim();
    const koszt = parseFloat(document.getElementById('koszt').value);
    const ilosc = parseInt(document.getElementById('ilosc').value);
    const marka = document.getElementById('marka').value.trim();
    const stan = document.getElementById('stan').value;

    if (!nazwa || !marka) {
      alert('Nazwa i marka muszą być podane!');
      return;
    }
    if (isNaN(koszt) || koszt < 0) {
      alert('Koszt musi być liczbą większą lub równą 0!');
      return;
    }
    if (isNaN(ilosc) || ilosc < 0) {
      alert('Ilość musi być liczbą większą lub równą 0!');
      return;
    }

    const czesc = { id: Date.now(), nazwa, koszt, ilosc, marka, stan };
    czesci.push(czesc);
    aktualnosci.unshift(`Dodano część: ${nazwa}`);
    renderCzesci();
    renderAktualnosci();
    saveData();
    event.target.reset();
  }
});

function renderCzesci() {
  const czesciList = document.getElementById('czesciList');
  czesciList.innerHTML = '';
  czesci.forEach(czesc => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td contenteditable="true">${czesc.nazwa}</td>
      <td contenteditable="true">${czesc.koszt}</td>
      <td contenteditable="true">${czesc.ilosc}</td>
      <td contenteditable="true">${czesc.marka}</td>
      <td>
        <select id="stan-${czesc.id}">
          <option value="nowy" ${czesc.stan === 'nowy' ? 'selected' : ''}>Nowy</option>
          <option value="używany" ${czesc.stan === 'używany' ? 'selected' : ''}>Używany</option>
          <option value="igła" ${czesc.stan === 'igła' ? 'selected' : ''}>Igła</option>
          <option value="regenerowany" ${czesc.stan === 'regenerowany' ? 'selected' : ''}>Regenerowany</option>
          <option value="uszkodzony" ${czesc.stan === 'uszkodzony' ? 'selected' : ''}>Uszkodzony</option>
          <option value="demo" ${czesc.stan === 'demo' ? 'selected' : ''}>Demo</option>
          <option value="zwrot" ${czesc.stan === 'zwrot' ? 'selected' : ''}>Zwrot</option>
        </select>
      </td>
      <td>
        <button onclick="sprzedajCzesc(${czesc.id})">Sprzedaj</button>
        <button onclick="usunCzesc(${czesc.id})">Usuń</button>
        <button onclick="zatwierdzEdycje(${czesc.id})">Zatwierdź</button>
      </td>
    `;
    czesciList.appendChild(row);
  });
}

function zatwierdzEdycje(id) {
  const czesc = czesci.find(c => c.id === id);
  const row = document.getElementById(`stan-${id}`).closest('tr');
  const cells = row.querySelectorAll('td');

  const nowyKoszt = parseFloat(cells[1].innerText);
  const nowaIlosc = parseInt(cells[2].innerText);

  if (isNaN(nowyKoszt) || nowyKoszt < 0) {
    alert('Koszt nie może być ujemny ani pusty!');
    return;
  }
  if (isNaN(nowaIlosc) || nowaIlosc < 0) {
    alert('Ilość nie może być ujemna ani pusta!');
    return;
  }

  czesc.nazwa = cells[0].innerText;
  czesc.koszt = nowyKoszt;
  czesc.ilosc = nowaIlosc;
  czesc.marka = cells[3].innerText;
  czesc.stan = document.getElementById(`stan-${id}`).value;

  aktualnosci.unshift(`Edytowano część: ${czesc.nazwa}`);
  saveData();
  renderAktualnosci();
}

function sprzedajCzesc(id) {
  const czesc = czesci.find(c => c.id === id);
  const iloscDoSprzedazy = prompt('Podaj ilość do sprzedaży:');
  if (iloscDoSprzedazy !== null && iloscDoSprzedazy !== '' && !isNaN(iloscDoSprzedazy)) {
    const ilosc = parseInt(iloscDoSprzedazy);
    if (czesc.ilosc >= ilosc && ilosc > 0) {
      czesc.ilosc -= ilosc;
      const wartosc = ilosc * czesc.koszt;
      historia.push(`Sprzedano ${ilosc} szt. ${czesc.nazwa} za ${wartosc.toFixed(2)} zł`);
      renderCzesci();
      renderHistoria();
      saveData();
    } else {
      alert('Za mało sztuk na stanie lub nieprawidłowa ilość!');
    }
  }
}

function usunCzesc(id) {
  if (confirm('Czy na pewno chcesz usunąć tę część?')) {
    czesci = czesci.filter(c => c.id !== id);
    aktualnosci.unshift(`Usunięto część ID ${id}`);
    renderCzesci();
    renderAktualnosci();
    saveData();
  }
}

function renderHistoria() {
  const historiaList = document.getElementById('historiaList');
  historiaList.innerHTML = '';
  historia.forEach(entry => {
    const li = document.createElement('li');
    li.textContent = entry;
    historiaList.appendChild(li);
  });
}

function renderAktualnosci() {
  const aktualnosciList = document.getElementById('aktualnosciList');
  aktualnosciList.innerHTML = '';
  aktualnosci.forEach(entry => {
    const li = document.createElement('li');
    li.textContent = entry;
    aktualnosciList.appendChild(li);
  });
}

function renderStatystyki() {
  const marki = {};
  const listaTowarow = document.getElementById('listaTowarow');
  listaTowarow.innerHTML = '';

  czesci.forEach(czesc => {
    marki[czesc.marka] = (marki[czesc.marka] || 0) + czesc.ilosc;
    const li = document.createElement('li');
    li.textContent = `${czesc.nazwa} (${czesc.ilosc} szt.)`;
    listaTowarow.appendChild(li);
  });

  const labels = Object.keys(marki);
  const data = Object.values(marki);

  const ctx = document.getElementById('chart').getContext('2d');
  if (chart) chart.destroy();
  chart = new Chart(ctx, {
    type: 'pie',
    data: {
      labels: labels,
      datasets: [{
        label: 'Ilość części',
        data: data,
        backgroundColor: [
          '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40', '#C9CBCF'
        ]
      }]
    }
  });
}

function toggleEditPanel() {
  const panel = document.getElementById('editPanel');
  panel.style.display = (panel.style.display === 'block') ? 'none' : 'block';
}

function saveUserData() {
  const newName = document.getElementById('editName').value;
  const newEmail = document.getElementById('editEmail').value;
  const newPhone = document.getElementById('editPhone').value;

  if (newName.trim()) {
    localStorage.setItem('userName', newName.trim());
    document.getElementById('userName').textContent = newName;
  }
  if (newEmail.trim()) {
    localStorage.setItem('userEmail', newEmail.trim());
    document.getElementById('userEmail').textContent = newEmail;
  }
  if (newPhone.trim()) {
    localStorage.setItem('userPhone', newPhone.trim());
    document.getElementById('userPhone').textContent = newPhone;
  }

  toggleEditPanel();
}