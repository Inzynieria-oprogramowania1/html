const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const bodyParser = require('body-parser');
const app = express();
const PORT = 3000;

// Połączenie z SQLite
const db = new sqlite3.Database('./magazyn.db', (err) => {
  if (err) {
    console.error('Błąd połączenia z bazą SQLite:', err.message);
  } else {
    console.log('Połączono z bazą SQLite');
  }
});

// Tworzenie tabeli czesci jeśli nie istnieje
db.run(`
  CREATE TABLE IF NOT EXISTS czesci (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nazwa TEXT,
    koszt REAL,
    ilosc INTEGER,
    marka TEXT,
    stan TEXT
  )
`);

app.use(cors());
app.use(express.static('public'));
app.use(bodyParser.json());

// Pobranie wszystkich części
app.get('/api/czesci', (req, res) => {
  db.all('SELECT * FROM czesci', [], (err, rows) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.json(rows);
    }
  });
});

// Dodanie nowej części
app.post('/api/czesci', (req, res) => {
  const { nazwa, koszt, ilosc, marka, stan } = req.body;
  db.run(
    `INSERT INTO czesci (nazwa, koszt, ilosc, marka, stan) VALUES (?, ?, ?, ?, ?)`,
    [nazwa, koszt, ilosc, marka, stan],
    function (err) {
      if (err) {
        res.status(500).json({ error: err.message });
      } else {
        res.json({ id: this.lastID });
      }
    }
  );
});

// Sprzedaż części (zmniejszenie ilości)
app.put('/api/czesci/:id', (req, res) => {
  const id = req.params.id;
  const { ilosc } = req.body;
  db.run(
    `UPDATE czesci SET ilosc = ilosc - ? WHERE id = ? AND ilosc >= ?`,
    [ilosc, id, ilosc],
    function (err) {
      if (err) {
        res.status(500).json({ error: err.message });
      } else {
        if (this.changes === 0) {
          res.status(400).json({ error: 'Za mało sztuk na magazynie' });
        } else {
          res.json({ success: true });
        }
      }
    }
  );
});

app.listen(PORT, () => {
  console.log(`Serwer działa na http://localhost:${PORT}`);
});
